from django.db import models
from django.contrib.auth.models import AbstractUser
from django.utils import timezone

# import datetime

# Define user types. Either 'vendor' or 'buyer'.
USER_TYPE_CHOICES = (
    ("vendor", "Vendor"),
    ("buyer", "Buyer"),
)


class User(AbstractUser):
    """
    Custom User model extending Django's AbstractUser to include user type.
    """

    user_type = models.CharField(
        max_length=10, choices=USER_TYPE_CHOICES, default="buyer"
    )

    def is_vendor(self):
        """Checks if the user is a vendor."""
        return self.user_type == "vendor"

    def is_buyer(self):
        """Checks if the user is a buyer."""
        return self.user_type == "buyer"


class Store(models.Model):
    """
    Model representing a vendor's store.
    """

    vendor = models.ForeignKey(User, on_delete=models.CASCADE, related_name="stores")
    name = models.CharField(max_length=255)
    description = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    logo = models.ImageField(upload_to='store_logos/', blank=True, null=True) # Added logo field

    class Meta:
        verbose_name = "Store"
        verbose_name_plural = "Stores"
        unique_together = (
            "vendor",
            "name",
        )  # Validation for A vendor cannot have two stores with the same name

    def __str__(self):
        return f"{self.name} by {self.vendor.username}"


class Product(models.Model):
    """
    Model representing a product within a store.
    """

    store = models.ForeignKey(Store, on_delete=models.CASCADE, related_name="products")
    name = models.CharField(max_length=255)
    description = models.TextField(blank=True, null=True)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    stock = models.IntegerField(default=0)
    image = models.ImageField(upload_to="products/", blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Product"
        verbose_name_plural = "Products"
        unique_together = (
            "store",
            "name",
        )  # A store cannot have two products with the same name

    def __str__(self):
        return f"{self.name} ({self.store.name})"


class CartItem(models.Model):
    """
    Model representing an item in a buyer's shopping cart.
    This is used when a buyer is logged in. For anonymous users, sessions are used.
    """

    buyer = models.ForeignKey(User, on_delete=models.CASCADE, related_name="cart_items")
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)
    added_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Cart Item"
        verbose_name_plural = "Cart Items"
        unique_together = (
            "buyer",
            "product",
        )  # A buyer can only have one entry per product in their cart

    def __str__(self):
        return f"{self.quantity} x {self.product.name} for {self.buyer.username}"

    @property
    def total_price(self):
        """Calculates the total price for this cart item."""
        return self.quantity * self.product.price


class Order(models.Model):
    """
    Model representing a buyer's order after checkout.
    """

    buyer = models.ForeignKey(User, on_delete=models.CASCADE, related_name="orders")
    order_date = models.DateTimeField(auto_now_add=True)
    total_amount = models.DecimalField(max_digits=10, decimal_places=2)
    is_paid = models.BooleanField(default=False)

    class Meta:
        verbose_name = "Order"
        verbose_name_plural = "Orders"
        ordering = ["-order_date"]  # Order by most recent first

    def __str__(self):
        return f"Order #{self.id} by {self.buyer.username} on {self.order_date.strftime('%Y-%m-%d')}"


class OrderItem(models.Model):
    """
    Model representing a specific product within an order.
    """

    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name="items")
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField()
    price = models.DecimalField(
        max_digits=10, decimal_places=2
    )  # Price at the time of purchase

    class Meta:
        verbose_name = "Order Item"
        verbose_name_plural = "Order Items"
        unique_together = ("order", "product")

    def __str__(self):
        return f"{self.quantity} x {self.product.name} in Order #{self.order.id}"

    @property
    def total_price(self):
        """Calculates the total price for this order item."""
        return self.quantity * self.price


class Review(models.Model):
    """
    Model for product reviews.
    """

    product = models.ForeignKey(
        Product, on_delete=models.CASCADE, related_name="reviews"
    )
    buyer = models.ForeignKey(User, on_delete=models.CASCADE, related_name="reviews")
    rating = models.PositiveIntegerField(
        choices=[(i, str(i)) for i in range(1, 6)]
    )  # 1 to 5 stars
    comment = models.TextField()
    is_verified = models.BooleanField(
        default=False
    )  # True if buyer purchased the product
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Review"
        verbose_name_plural = "Reviews"
        unique_together = (
            "product",
            "buyer",
        )  # A buyer can only leave one review per product
        ordering = ["-created_at"]

    def __str__(self):
        return f"Review for {self.product.name} by {self.buyer.username} - {self.rating} stars ({'Verified' if self.is_verified else 'Unverified'})"


class PasswordResetToken(models.Model):
    """
    Model to store password reset tokens.
    """

    user = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name="password_reset_tokens"
    )
    token = models.CharField(max_length=100, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)
    # Token expires after 1 hour
    # expires_at = models.DateTimeField(default=lambda: timezone.now() + datetime.timedelta(hours=1))

    class Meta:
        verbose_name = "Password Reset Token"
        verbose_name_plural = "Password Reset Tokens"

    def __str__(self):
        return f"Token for {self.user.username} - Expires: {self.expires_at}"

    def is_valid(self):
        """Checks if the token is still valid (not expired)."""
        return timezone.now() < self.expires_at
