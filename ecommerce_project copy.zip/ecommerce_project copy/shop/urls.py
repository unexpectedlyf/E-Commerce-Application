from django.urls import path
from .views import (
    VendorRegistrationView,
    BuyerRegistrationView,
    UserLoginView,
    UserLogoutView,
    StoreListView,
    StoreCreateView,
    StoreUpdateView,
    StoreDeleteView,
    ProductListView,
    ProductCreateView,
    ProductUpdateView,
    ProductDeleteView,
    product_list_all,
    add_to_cart,
    view_cart,
    remove_from_cart,
    checkout,
    add_review,
    password_reset_request,
    CustomPasswordResetDoneView,
    password_reset_confirm,
    CustomPasswordResetCompleteView,
    download_invoice_pdf,  # import for PDF download
)

urlpatterns = [
    # Authentication URLs
    path("register/vendor/", VendorRegistrationView.as_view(), name="register-vendor"),
    path("register/buyer/", BuyerRegistrationView.as_view(), name="register-buyer"),
    path("login/", UserLoginView.as_view(), name="login"),
    path("logout/", UserLogoutView.as_view(), name="logout"),
    # Password Reset URLs
    path("password-reset/", password_reset_request, name="password-reset-request"),
    path(
        "password-reset/done/",
        CustomPasswordResetDoneView.as_view(),
        name="password-reset-done",
    ),
    # uidb64 is user.id, token is the token generated
    path(
        "password-reset-confirm/<int:uidb64>/<str:token>/",
        password_reset_confirm,
        name="password-reset-confirm",
    ),
    path(
        "password-reset/complete/",
        CustomPasswordResetCompleteView.as_view(),
        name="password-reset-complete",
    ),
    # Vendor URLs (Stores)
    path("stores/", StoreListView.as_view(), name="store-list"),
    path("stores/create/", StoreCreateView.as_view(), name="store-create"),
    path("stores/<int:pk>/edit/", StoreUpdateView.as_view(), name="store-edit"),
    path("stores/<int:pk>/delete/", StoreDeleteView.as_view(), name="store-delete"),
    # Vendor URLs (Products within a store)
    path(
        "stores/<int:store_id>/products/",
        ProductListView.as_view(),
        name="product-list",
    ),
    path(
        "stores/<int:store_id>/products/add/",
        ProductCreateView.as_view(),
        name="product-add",
    ),
    path("products/<int:pk>/edit/", ProductUpdateView.as_view(), name="product-edit"),
    path(
        "products/<int:pk>/delete/", ProductDeleteView.as_view(), name="product-delete"
    ),
    # Buyer URLs
    # path('', product_list_all, name='home'), # Defined in project urls.py as home
    path("products/", product_list_all, name="all-products"),  # Alias for home
    path("cart/add/<int:product_id>/", add_to_cart, name="add-to-cart"),
    path("cart/", view_cart, name="view-cart"),
    path("cart/remove/<int:product_id>/", remove_from_cart, name="remove-from-cart"),
    path("checkout/", checkout, name="checkout"),
    path("products/<int:product_id>/review/", add_review, name="add-review"),
    # PDF Download URL
    path(
        "invoice/download/<int:order_id>/",
        download_invoice_pdf,
        name="download-invoice-pdf",
    ),
]
