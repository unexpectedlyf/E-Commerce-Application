from rest_framework import serializers
from .models import User, Store, Product, Review

class StoreSerializer(serializers.ModelSerializer):
    class Meta:
        model = Store
        fields = '__all__' # Use all fields
        read_only_fields = ['id', 'vendor', 'created_at', 'updated_at'] # Mark auto-generated and vendor as read-only

class ProductSerializer(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = ['id', 'store', 'name', 'description', 'price', 'stock', 'image', 'created_at', 'updated_at']
        read_only_fields = ['id', 'created_at', 'updated_at']

class ReviewSerializer(serializers.ModelSerializer):
    # Display the buyer's username instead of just their ID
    buyer_username = serializers.CharField(source='buyer.username', read_only=True)

    class Meta:
        model = Review
        fields = ['id', 'product', 'buyer', 'buyer_username', 'rating', 'comment', 'is_verified', 'created_at', 'updated_at']
        read_only_fields = ['id', 'buyer', 'is_verified', 'created_at', 'updated_at'] # Buyer and is_verified set by view
