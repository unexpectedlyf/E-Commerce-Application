from django.urls import path
from . import api_views

urlpatterns = [
    # API for Stores
    path('stores/', api_views.store_list_create_api, name='api-store-list-create'),
    path('stores/<int:pk>/', api_views.store_detail_api, name='api-store-detail'),

    # API for Products within a specific store
    path('stores/<int:store_id>/products/', api_views.product_list_create_api, name='api-product-list-create'),
    path('products/<int:pk>/', api_views.product_detail_api, name='api-product-detail'), # For product detail by product ID

    # API for Reviews (retrieval only for now)
    path('products/<int:product_id>/reviews/', api_views.review_list_api, name='api-review-list'),
]
