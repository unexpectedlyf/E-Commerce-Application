from django.shortcuts import render, redirect, get_object_or_404
from django.views.generic import CreateView, ListView, UpdateView, DeleteView
from django.contrib.auth.views import (
    LoginView,
    LogoutView,
    PasswordResetDoneView,
    PasswordResetCompleteView,
)
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.urls import reverse_lazy
from django.contrib import messages
from django.db import transaction
from django.contrib.sessions.models import Session
from django.utils import timezone
import datetime

# For PDF generation
from django.http import HttpResponse
from django.template.loader import get_template
from xhtml2pdf import (
    pisa,
)
import io


from .models import (
    User,
    Store,
    Product,
    CartItem,
    Order,
    OrderItem,
    Review,
    PasswordResetToken,
)
from .forms import (
    VendorRegistrationForm,
    BuyerRegistrationForm,
    LoginForm,
    StoreForm,
    ProductForm,
    ReviewForm,
    PasswordResetRequestForm,
    SetNewPasswordForm,
)
from .utils import (
    send_password_reset_email,
    send_invoice_email,
    generate_unique_token,
)  # Import generate_unique_token


# --- Authentication Views ---


class VendorRegistrationView(CreateView):
    """
    View for vendor registration.
    """

    model = User
    form_class = VendorRegistrationForm
    template_name = "shop/register_vendor.html"
    success_url = reverse_lazy(
        "login"
    )  # Redirect to login after successful registration

    def form_valid(self, form):
        response = super().form_valid(form)
        messages.success(
            self.request, "Vendor account created successfully! Please log in."
        )
        return response


class BuyerRegistrationView(CreateView):
    """
    View for buyer registration.
    """

    model = User
    form_class = BuyerRegistrationForm
    template_name = "shop/register_buyer.html"
    success_url = reverse_lazy(
        "login"
    )  # Redirect to login after successful registration

    def form_valid(self, form):
        response = super().form_valid(form)
        messages.success(
            self.request, "Buyer account created successfully! Please log in."
        )
        return response


class UserLoginView(LoginView):
    """
    View for user login.
    """

    template_name = "shop/login.html"
    authentication_form = LoginForm

    def get_success_url(self):
        # Redirect based on user type after login
        if self.request.user.is_authenticated:
            if self.request.user.is_vendor():
                messages.info(
                    self.request,
                    f"Welcome back, {self.request.user.username} (Vendor)!",
                )
                return reverse_lazy("store-list")
            elif self.request.user.is_buyer():
                messages.info(
                    self.request, f"Welcome back, {self.request.user.username} (Buyer)!"
                )
                return reverse_lazy("home")  # Redirect to all products for buyers
        return reverse_lazy("home")  # Fallback

    def form_invalid(self, form):
        messages.error(self.request, "Invalid username or password.")
        return super().form_invalid(form)


class UserLogoutView(LogoutView):
    """
    View for user logout.
    """

    next_page = reverse_lazy("login")  # Redirect to login page after logout

    def dispatch(self, request, *args, **kwargs):
        messages.info(request, "You have been logged out.")
        return super().dispatch(request, *args, **kwargs)


# --- Vendor Views ---


class IsVendorMixin(UserPassesTestMixin):
    """
    Mixin to ensure only vendors can access the view.
    """

    def test_func(self):
        return self.request.user.is_authenticated and self.request.user.is_vendor()

    def handle_no_permission(self):
        messages.error(
            self.request,
            "You do not have permission to access this page. Only vendors can.",
        )
        return redirect("home")  # Or a more appropriate unauthorized page


class StoreListView(LoginRequiredMixin, IsVendorMixin, ListView):
    """
    Displays a list of stores owned by the logged-in vendor.
    """

    model = Store
    template_name = "shop/store_list.html"
    context_object_name = "stores"

    def get_queryset(self):
        return Store.objects.filter(vendor=self.request.user)


class StoreCreateView(LoginRequiredMixin, IsVendorMixin, CreateView):
    """
    Allows a vendor to create a new store.
    """

    model = Store
    form_class = StoreForm
    template_name = "shop/store_form.html"
    success_url = reverse_lazy("store-list")

    def form_valid(self, form):
        form.instance.vendor = (
            self.request.user
        )  # Assign the current user as the vendor
        response = super().form_valid(form)
        messages.success(
            self.request, f'Store "{form.instance.name}" created successfully!'
        )
        return response


class StoreUpdateView(LoginRequiredMixin, IsVendorMixin, UpdateView):
    """
    Allows a vendor to edit their existing store.
    """

    model = Store
    form_class = StoreForm
    template_name = "shop/store_form.html"
    context_object_name = "store"
    pk_url_kwarg = "pk"  # The URL keyword argument for the primary key

    def get_queryset(self):
        # Ensuring only the vendor who owns the store can update it
        return Store.objects.filter(vendor=self.request.user)

    def get_success_url(self):
        messages.success(
            self.request, f'Store "{self.object.name}" updated successfully!'
        )
        return reverse_lazy("store-list")


class StoreDeleteView(LoginRequiredMixin, IsVendorMixin, DeleteView):
    """
    Allows a vendor to delete their store.
    """

    model = Store
    template_name = "shop/store_confirm_delete.html"
    context_object_name = "store"
    pk_url_kwarg = "pk"
    success_url = reverse_lazy("store-list")

    def get_queryset(self):
        # Ensuring only the vendor who owns the store can delete it
        return Store.objects.filter(vendor=self.request.user)

    def form_valid(self, form):
        messages.success(
            self.request, f'Store "{self.object.name}" deleted successfully!'
        )
        return super().form_valid(form)


class ProductListView(LoginRequiredMixin, IsVendorMixin, ListView):
    """
    Displays a list of products for a specific store owned by the logged-in vendor.
    """

    model = Product
    template_name = "shop/product_list.html"
    context_object_name = "products"

    def get_queryset(self):
        store_id = self.kwargs["store_id"]
        # Ensure the store belongs to the current vendor
        store = get_object_or_404(Store, id=store_id, vendor=self.request.user)
        return Product.objects.filter(store=store)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["store"] = get_object_or_404(
            Store, id=self.kwargs["store_id"], vendor=self.request.user
        )
        return context


class ProductCreateView(LoginRequiredMixin, IsVendorMixin, CreateView):
    """
    Allows a vendor to add a new product to a specific store.
    """

    model = Product
    form_class = ProductForm
    template_name = "shop/product_form.html"

    def dispatch(self, request, *args, **kwargs):
        self.store = get_object_or_404(
            Store, id=self.kwargs["store_id"], vendor=request.user
        )
        return super().dispatch(request, *args, **kwargs)

    def form_valid(self, form):
        form.instance.store = self.store  # Assigning the product to the correct store
        response = super().form_valid(form)
        messages.success(
            self.request,
            f'Product "{form.instance.name}" added successfully to {self.store.name}!',
        )
        return response

    def get_success_url(self):
        return reverse_lazy("product-list", kwargs={"store_id": self.store.id})

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["store"] = self.store
        return context


class ProductUpdateView(LoginRequiredMixin, IsVendorMixin, UpdateView):
    """
    Allows a vendor to edit an existing product in their store.
    """

    model = Product
    form_class = ProductForm
    template_name = "shop/product_form.html"
    context_object_name = "product"
    pk_url_kwarg = "pk"  # The URL keyword argument for the primary key

    def get_queryset(self):
        # Ensure the product belongs to a store owned by the current vendor
        return Product.objects.filter(store__vendor=self.request.user)

    def get_success_url(self):
        messages.success(
            self.request, f'Product "{self.object.name}" updated successfully!'
        )
        return reverse_lazy("product-list", kwargs={"store_id": self.object.store.id})

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["store"] = self.object.store
        return context


class ProductDeleteView(LoginRequiredMixin, IsVendorMixin, DeleteView):
    """
    Allows a vendor to delete a product from their store.
    """

    model = Product
    template_name = "shop/product_confirm_delete.html"
    context_object_name = "product"
    pk_url_kwarg = "pk"

    def get_queryset(self):
        # Ensuring the product belongs to a store owned by the current vendor
        return Product.objects.filter(store__vendor=self.request.user)

    def get_success_url(self):
        messages.success(
            self.request, f'Product "{self.object.name}" deleted successfully!'
        )
        return reverse_lazy("product-list", kwargs={"store_id": self.object.store.id})

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["store"] = self.object.store
        return context


# --- Buyer Views ---


class IsBuyerMixin(UserPassesTestMixin):
    """
    Mixin to ensure only buyers can access the view.
    """

    def test_func(self):
        return self.request.user.is_authenticated and self.request.user.is_buyer()

    def handle_no_permission(self):
        messages.error(
            self.request,
            "You do not have permission to access this page. Only buyers can.",
        )
        return redirect("home")  # Or a more appropriate unauthorized page


def product_list_all(request):
    """
    Displays all products from all stores for buyers.
    This is also the home page.
    """
    products = Product.objects.all().order_by("-created_at")
    return render(request, "shop/all_products.html", {"products": products})


def add_to_cart(request, product_id):
    """
    Adds a product to the user's cart (session for anonymous, CartItem model for logged-in buyers).
    """
    product = get_object_or_404(Product, id=product_id)
    quantity = int(request.POST.get("quantity", 1))

    if quantity <= 0:
        messages.error(request, "Quantity must be at least 1.")
        return redirect("home")

    if product.stock < quantity:
        messages.error(
            request, f"Not enough stock for {product.name}. Available: {product.stock}"
        )
        return redirect("home")

    if request.user.is_authenticated and request.user.is_buyer():
        # For logged-in buyers, use the CartItem model
        cart_item, created = CartItem.objects.get_or_create(
            buyer=request.user, product=product, defaults={"quantity": quantity}
        )
        if not created:
            # Check if adding more exceeds stock
            if cart_item.quantity + quantity > product.stock:
                messages.error(
                    request,
                    f"Adding {quantity} more of {product.name} would exceed available stock ({product.stock}). You currently have {cart_item.quantity} in your cart.",
                )
                return redirect("home")
            cart_item.quantity += quantity
            cart_item.save()
        messages.success(request, f"{quantity} x {product.name} added to your cart.")
    else:
        # For anonymous users, use session
        cart = request.session.get("cart", {})
        product_id_str = str(product_id)

        current_quantity_in_cart = cart.get(product_id_str, 0)
        if current_quantity_in_cart + quantity > product.stock:
            messages.error(
                request,
                f"Adding {quantity} more of {product.name} would exceed available stock ({product.stock}). You currently have {current_quantity_in_cart} in your cart.",
            )
            return redirect("home")

        cart[product_id_str] = cart.get(product_id_str, 0) + quantity
        request.session["cart"] = cart
        messages.success(
            request, f"{quantity} x {product.name} added to your session cart."
        )

    return redirect("view-cart")


def view_cart(request):
    """
    Displays the contents of the user's cart.
    """
    cart_items = []
    total_cart_price = 0

    if request.user.is_authenticated and request.user.is_buyer():
        # For logged-in buyers, fetch from CartItem model
        cart_items = CartItem.objects.filter(buyer=request.user).select_related(
            "product"
        )
        for item in cart_items:
            total_cart_price += item.total_price
    else:
        # For anonymous users, reconstruct cart from session
        session_cart = request.session.get("cart", {})
        for product_id, quantity in session_cart.items():
            try:
                product = Product.objects.get(id=int(product_id))
                cart_items.append(
                    {
                        "product": product,
                        "quantity": quantity,
                        "total_price": product.price * quantity,
                    }
                )
                total_cart_price += product.price * quantity
            except Product.DoesNotExist:
                # Remove invalid product from session cart
                del request.session["cart"][product_id]
                request.session.modified = True
                messages.warning(
                    request,
                    f"A product in your cart (ID: {product_id}) was not found and has been removed.",
                )

    return render(
        request,
        "shop/cart.html",
        {"cart_items": cart_items, "total_cart_price": total_cart_price},
    )


def remove_from_cart(request, product_id):
    """
    Removes a product from the user's cart.
    """
    product = get_object_or_404(Product, id=product_id)

    if request.user.is_authenticated and request.user.is_buyer():
        # For logged-in buyers, remove from CartItem model
        try:
            cart_item = CartItem.objects.get(buyer=request.user, product=product)
            cart_item.delete()
            messages.info(request, f"{product.name} removed from your cart.")
        except CartItem.DoesNotExist:
            messages.warning(request, f"{product.name} was not found in your cart.")
    else:
        # For anonymous users, remove from session
        cart = request.session.get("cart", {})
        product_id_str = str(product_id)
        if product_id_str in cart:
            del cart[product_id_str]
            request.session["cart"] = cart
            messages.info(request, f"{product.name} removed from your session cart.")
        else:
            messages.warning(
                request, f"{product.name} was not found in your session cart."
            )

    return redirect("view-cart")


@transaction.atomic
def checkout(request):
    """
    Handles the checkout process: creates an order, clears cart, updates stock, sends invoice.
    """
    if not request.user.is_authenticated or not request.user.is_buyer():
        messages.error(request, "You must be logged in as a buyer to checkout.")
        return redirect("login")

    buyer = request.user
    cart_items_data = []  # To store product and quantity for order creation

    # Fetch cart items for the logged-in buyer
    cart_items = CartItem.objects.filter(buyer=buyer).select_related("product")
    if not cart_items.exists():
        messages.warning(
            request, "Your cart is empty. Please add products before checking out."
        )
        return redirect("view-cart")

    total_order_amount = 0
    products_to_update_stock = []  # List of (product, quantity) to update stock

    # Validate stock and prepare data for order creation
    for item in cart_items:
        product = item.product
        quantity = item.quantity

        if product.stock < quantity:
            messages.error(
                request,
                f"Insufficient stock for {product.name}. Only {product.stock} available. Please adjust your cart.",
            )
            # Rollback the transaction if stock is insufficient
            raise Exception(
                "Insufficient stock during checkout."
            )  # This will trigger a rollback

        cart_items_data.append(
            {
                "product": product,
                "quantity": quantity,
                "price_at_purchase": product.price,  # Record price at time of purchase
            }
        )
        total_order_amount += item.total_price
        products_to_update_stock.append({"product": product, "quantity": quantity})

    try:
        # Create the Order
        order = Order.objects.create(
            buyer=buyer, total_amount=total_order_amount, is_paid=True
        )  # Assume paid for simplicity

        # Create OrderItems and update product stock
        for item_data in cart_items_data:
            OrderItem.objects.create(
                order=order,
                product=item_data["product"],
                quantity=item_data["quantity"],
                price=item_data["price_at_purchase"],
            )
            # Update product stock
            product = item_data["product"]
            product.stock -= item_data["quantity"]
            product.save()

        # Clear the buyer's cart
        cart_items.delete()

        # Send invoice email
        send_invoice_email(buyer, order)

        messages.success(
            request,
            f"Your order #{order.id} has been placed successfully! An invoice has been sent to your email.",
        )
        return render(request, "shop/checkout_success.html", {"order": order})

    except Exception as e:
        messages.error(
            request, f"An error occurred during checkout: {e}. Please try again."
        )
        # The @transaction.atomic decorator will automatically roll back if an exception occurs
        return redirect("view-cart")


def add_review(request, product_id):
    """
    Allows a buyer to add a review for a product.
    Determines if the review is verified based on past purchases.
    """
    product = get_object_or_404(Product, id=product_id)

    if not request.user.is_authenticated or not request.user.is_buyer():
        messages.error(request, "You must be logged in as a buyer to leave a review.")
        return redirect("login")

    buyer = request.user

    # Check if the buyer has already reviewed this product
    if Review.objects.filter(product=product, buyer=buyer).exists():
        messages.warning(request, "You have already reviewed this product.")
        return redirect("home")  # Or redirect to product detail page

    if request.method == "POST":
        form = ReviewForm(request.POST)
        if form.is_valid():
            review = form.save(commit=False)
            review.product = product
            review.buyer = buyer

            # Determine if the review is verified
            # A review is verified if the buyer has purchased this product at least once
            has_purchased = OrderItem.objects.filter(
                order__buyer=buyer,
                product=product,
                order__is_paid=True,  # Only consider paid orders
            ).exists()
            review.is_verified = has_purchased
            review.save()

            messages.success(request, "Your review has been submitted successfully!")
            return redirect("home")  # Or redirect to product detail page
        else:
            messages.error(request, "Please correct the errors in the review form.")
    else:
        form = ReviewForm()

    return render(request, "shop/add_review.html", {"form": form, "product": product})


def download_invoice_pdf(request, order_id):
    """
    Generates and downloads a PDF invoice for a given order.
    Ensures only the buyer who placed the order can download it.
    """
    if not request.user.is_authenticated or not request.user.is_buyer():
        messages.error(
            request, "You must be logged in as a buyer to download invoices."
        )
        return redirect("login")

    order = get_object_or_404(Order, id=order_id, buyer=request.user)

    template_path = "shop/invoice_pdf_template.html"
    context = {"order": order, "buyer": request.user}
    template = get_template(template_path)
    html = template.render(context)

    # Create a PDF file
    result = io.BytesIO()
    pdf = pisa.CreatePDF(
        io.StringIO(html),  # The HTML to convert
        dest=result,  # File handle to receive result
        encoding="UTF-8",
    )

    if not pdf.err:
        response = HttpResponse(result.getvalue(), content_type="application/pdf")
        response["Content-Disposition"] = (
            f'attachment; filename="invoice_order_{order.id}.pdf"'
        )
        return response
    messages.error(request, "Error generating PDF invoice.")
    return redirect(
        "checkout-success", order.id
    )  # Redirect back to success page if error


# --- Password Recovery Views ---


def password_reset_request(request):
    """
    Allows a user to request a password reset by entering their email.
    """
    if request.method == "POST":
        form = PasswordResetRequestForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data["email"]
            user = User.objects.filter(email=email).first()
            if user:
                # Invalidate any existing tokens for this user
                # This line is crucial to prevent the UNIQUE constraint error
                PasswordResetToken.objects.filter(user=user).delete()

                # Generate a new token and save it
                # Ensure the 'token' field is explicitly set here
                new_token_value = generate_unique_token()
                token_obj = PasswordResetToken.objects.create(
                    user=user, token=new_token_value
                )

                # Send the password reset email using the new token object's token value
                send_password_reset_email(user, token_obj.token, request)
                messages.success(
                    request,
                    "If an account with that email exists, we've sent instructions to reset your password.",
                )
            else:
                # Provide a generic message for security reasons, even if email doesn't exist
                messages.info(
                    request,
                    "If an account with that email exists, we've sent instructions to reset your password.",
                )
            return redirect("password-reset-done")
    else:
        form = PasswordResetRequestForm()
    return render(request, "shop/password_reset_request.html", {"form": form})


class CustomPasswordResetDoneView(PasswordResetDoneView):
    """
    Custom view for password reset done page.
    """

    template_name = "shop/password_reset_done.html"


def password_reset_confirm(request, uidb64, token):
    """
    Allows a user to set a new password using the reset token.
    """
    try:
        user_id = int(
            uidb64
        )  # uidb64 is actually the user.id in this custom implementation
        user = User.objects.get(pk=user_id)
    except (TypeError, ValueError, OverflowError, User.DoesNotExist):
        user = None

    reset_token = PasswordResetToken.objects.filter(user=user, token=token).first()

    if user is None or reset_token is None or not reset_token.is_valid():
        messages.error(request, "The password reset link is invalid or has expired.")
        return render(
            request,
            "shop/password_reset_confirm.html",
            {"form": None, "validlink": False},
        )

    if request.method == "POST":
        form = SetNewPasswordForm(user=user, data=request.POST)
        if form.is_valid():
            form.save()
            reset_token.delete()  # Invalidate the token after successful reset
            messages.success(
                request,
                "Your password has been reset successfully. You can now log in with your new password.",
            )
            return redirect("password-reset-complete")
        else:
            messages.error(request, "Please correct the errors below.")
    else:
        form = SetNewPasswordForm(user=user)

    return render(
        request, "shop/password_reset_confirm.html", {"form": form, "validlink": True}
    )


class CustomPasswordResetCompleteView(PasswordResetCompleteView):
    """
    Custom view for password reset complete page.
    """

    template_name = "shop/password_reset_complete.html"
    # No need for success_url here as it's the final page
