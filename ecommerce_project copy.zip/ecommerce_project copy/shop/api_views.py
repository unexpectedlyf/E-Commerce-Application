from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework import status
from django.conf import settings
from django.shortcuts import get_object_or_404
import tweepy
import os
from .models import Store, Product, Review
from django.contrib.auth import get_user_model # More robust way to get the User model
from .serializers import StoreSerializer, ProductSerializer, ReviewSerializer

User = get_user_model() # Get the active User model

# --- Twitter API Helper Function ---
def tweet_content(text):
    """
    Posts a plain text tweet.
    This is a placeholder function. In a real application, you would integrate
    with a Twitter API (e.g., using tweepy) to send the tweet.
    Media upload logic is explicitly removed as per request.
    """
    try:
       #Updated

        print(f"Simulating plain text tweet: '{text}'")
    except tweepy.TweepyException as e:
        print(f"Error tweeting: {e}")
    except Exception as e:
        print(f"An unexpected error occurred while tweeting: {e}")


# --- Store List/Create API View ---
@api_view(['GET', 'POST'])
@permission_classes([IsAuthenticated])
def store_list_create_api(request):
    """
    API endpoint to list all stores (for buyers/vendors) or create a new store (for vendors).
    """
    if request.method == 'GET':
        # Buyers can retrieve all stores
        # Vendors can retrieve their own stores
        # Check if the user belongs to the 'Vendors' group
        if request.user.groups.filter(name='Vendors').exists():
            stores = Store.objects.filter(vendor=request.user)
        else: # Assuming buyers can see all stores
            stores = Store.objects.all()
        serializer = StoreSerializer(stores, many=True)
        return Response(serializer.data)

    elif request.method == 'POST':
        # Only vendors can create stores
        # Check if the user belongs to the 'Vendors' group
        if not request.user.groups.filter(name='Vendors').exists():
            return Response(
                {'detail': 'Permission denied. Only vendors can create stores.'},
                status=status.HTTP_403_FORBIDDEN
            )

        serializer = StoreSerializer(data=request.data)
        if serializer.is_valid():
            # Automatically assign the vendor based on the authenticated user
            store = serializer.save(vendor=request.user)

            # --- Tweet when a new store is added ---
            store_name = store.name
            store_description = store.description
            tweet_text = f"📢 New Store Alert! 🎉\nName: {store_name}\nDescription: {store_description}"
            
            tweet_content(tweet_text) # Only plain text tweet
            # --- End Tweet Logic ---

            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

# --- Store Detail API View ---
@api_view(['GET', 'PUT', 'DELETE'])
@permission_classes([IsAuthenticated])
def store_detail_api(request, pk):
    store = get_object_or_404(Store, pk=pk)

    # Ensure only vendor who owns the store can edit/delete
    if request.user != store.vendor:
        return Response(
            {'detail': 'Permission denied. You do not own this store.'},
            status=status.HTTP_403_FORBIDDEN
        )

    if request.method == 'GET':
        serializer = StoreSerializer(store)
        return Response(serializer.data)

    elif request.method == 'PUT':
        # Ensure the vendor field is not modified via PUT
        # This check prevents a user from trying to reassign a store to another vendor
        if 'vendor' in request.data and int(request.data['vendor']) != request.user.id:
            return Response(
                {'detail': 'Vendor ID cannot be changed or must match authenticated user.'},
                status=status.HTTP_400_BAD_REQUEST
            )
        serializer = StoreSerializer(store, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save() # Vendor is already set, no need to pass it again
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    elif request.method == 'DELETE':
        store.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


# --- Product List/Create API View ---
@api_view(['GET', 'POST'])
@permission_classes([IsAuthenticated])
def product_list_create_api(request, store_id):
    store = get_object_or_404(Store, pk=store_id)

    # Only vendor who owns the store can add products to it
    if request.user != store.vendor:
        return Response(
            {'detail': 'Permission denied. You do not own this store.'},
            status=status.HTTP_403_FORBIDDEN
        )

    if request.method == 'GET':
        products = Product.objects.filter(store=store)
        serializer = ProductSerializer(products, many=True)
        return Response(serializer.data)

    elif request.method == 'POST':
        # The 'store' field in the request data is still needed to link the product to the correct store
        # but we don't need to check it against request.user.id if the URL already specifies the store_id
        if 'store' not in request.data or int(request.data['store']) != store_id:
             return Response(
                {'detail': 'Store ID in request data does not match URL path.'},
                status=status.HTTP_400_BAD_REQUEST
            )

        serializer = ProductSerializer(data=request.data)
        if serializer.is_valid():
            # Ensure product is associated with the correct store from the URL
            product = serializer.save(store=store) 

            # --- Tweet when a new product is added ---
            store_name = store.name
            product_name = product.name
            product_description = product.description
            tweet_text = f"🛍️ New Product Alert! From {store_name}:\n{product_name} - {product_description}"
            
            tweet_content(tweet_text) # Only plain text tweet
            # --- End Tweet Logic ---

            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# --- Product Detail API View ---
@api_view(['GET', 'PUT', 'DELETE'])
@permission_classes([IsAuthenticated])
def product_detail_api(request, pk):
    product = get_object_or_404(Product, pk=pk)

    # Ensure only vendor who owns the store selling the product can edit/delete
    if request.user != product.store.vendor:
        return Response(
            {'detail': 'Permission denied. You do not own this product\'s store.'},
            status=status.HTTP_403_FORBIDDEN
        )

    if request.method == 'GET':
        serializer = ProductSerializer(product)
        return Response(serializer.data)

    elif request.method == 'PUT':
        serializer = ProductSerializer(product, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    elif request.method == 'DELETE':
        product.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


# --- Review List API View ---
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def review_list_api(request, product_id):
    product = get_object_or_404(Product, pk=product_id)
    reviews = Review.objects.filter(product=product)
    serializer = ReviewSerializer(reviews, many=True)
    return Response(serializer.data)
