from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import (
    User,
    Store,
    Product,
    CartItem,
    Order,
    OrderItem,
    Review,
    PasswordResetToken,
)


# Custom UserAdmin to display user_type
class CustomUserAdmin(UserAdmin):
    fieldsets = UserAdmin.fieldsets + ((None, {"fields": ("user_type",)}),)
    add_fieldsets = UserAdmin.add_fieldsets + ((None, {"fields": ("user_type",)}),)
    list_display = ("username", "email", "user_type", "is_staff")
    list_filter = ("user_type", "is_staff", "is_active")


# Models registration for admin interface
admin.site.register(User, CustomUserAdmin)
admin.site.register(Store)
admin.site.register(Product)
admin.site.register(CartItem)
admin.site.register(Order)
admin.site.register(OrderItem)
admin.site.register(Review)
admin.site.register(PasswordResetToken)
