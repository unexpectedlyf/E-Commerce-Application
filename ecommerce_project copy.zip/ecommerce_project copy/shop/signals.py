# Signal to clean up expired password reset tokens
# Signals are used to perform actions automatically when certain events occur in the application.
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.utils import timezone
from .models import PasswordResetToken


@receiver(post_save, sender=PasswordResetToken)
def cleanup_old_password_reset_tokens(sender, instance, created, **kwargs):
    """
    Cleans up expired password reset tokens for the user after a new one is created.
    """
    if created:
        # Delete all expired tokens for this user
        PasswordResetToken.objects.filter(
            user=instance.user, expires_at__lt=timezone.now()
        ).delete()
        # Optionally, delete all other valid tokens for this user to ensure only the latest is active
        # This prevents multiple active reset links for the same user
        PasswordResetToken.objects.filter(user=instance.user).exclude(
            pk=instance.pk
        ).delete()
