# Utils for the eCommerce project
# This file contains utility functions for the eCommerce application, such as generating unique tokens and sending
import uuid
from django.core.mail import send_mail
from django.conf import settings
from django.template.loader import render_to_string
from django.utils.html import strip_tags


def generate_unique_token():
    """Generates a unique token using UUID4."""
    return str(uuid.uuid4())


def send_password_reset_email(user, token, request):
    """
    Sends a password reset email to the user.
    """
    # Build the reset URL (assuming the site is running on localhost:8000 for development)
    # In a production environment, you would use the actual domain.
    reset_url = request.build_absolute_uri(
        f"/password-reset-confirm/{user.id}/{token}/"
    )

    subject = "Password Reset Request for Your eCommerce Account"
    html_message = render_to_string(
        "shop/password_reset_email.html", {"user": user, "reset_url": reset_url}
    )
    plain_message = strip_tags(html_message)  # Fallback for plain text email

    try:
        send_mail(
            subject,
            plain_message,
            settings.DEFAULT_FROM_EMAIL,
            [user.email],
            html_message=html_message,
            fail_silently=False,
        )
        print(f"Password reset email sent to {user.email}")  # For debugging in console
    except Exception as e:
        print(f"Error sending password reset email to {user.email}: {e}")


def send_invoice_email(buyer, order):
    """
    Sends an invoice email to the buyer after checkout.
    """
    subject = f"Your eCommerce Order Confirmation - Order #{order.id}"
    html_message = render_to_string(
        "shop/invoice_email.html", {"buyer": buyer, "order": order}
    )
    plain_message = strip_tags(html_message)

    try:
        send_mail(
            subject,
            plain_message,
            settings.DEFAULT_FROM_EMAIL,
            [buyer.email],
            html_message=html_message,
            fail_silently=False,
        )
        print(
            f"Invoice email sent to {buyer.email} for order #{order.id}"
        )  # For debugging in console
    except Exception as e:
        print(f"Error sending invoice email to {buyer.email}: {e}")
